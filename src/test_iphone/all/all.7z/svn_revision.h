#ifndef __SVN_REVISION_H
#define __SVN_REVISION_H

#if 0
#define SVNREV "build:32 (modified)"
#else
#define SVNREV "build:32"
#endif

#endif // __SVN_REVISION_H
